from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from src.chat.schemas import *
from src.db.session import async_engine
from src.db.models.chat import Message
from src.db.models.chat import Chat
from src.db.models.user import User
from src.user.router import current_user

router_message = APIRouter()


@router_message.get("/messages/{chat_id}")
async def get_messages(chat_id: int) -> List[MessageReadModel]:
    async with AsyncSession(async_engine) as session:
        chat = await session.get(Chat, chat_id)
        if not chat:
            raise HTTPException(status_code=404, detail=f"Chat {chat_id} not found.")
        
        messages = await session.execute(select(Message).filter(Message.chat_id == chat_id))
        return messages.scalars().all()


@router_message.post("/message/create")
async def create_message(message: MessageCreateModel, user: User = Depends(current_user)) -> dict:
    async with AsyncSession(async_engine) as session:
        chat = await session.get(Chat, message.chat_id)
        if not chat:
            raise HTTPException(status_code=404, detail="Chat not found.")

        new_message = Message(
            content=message.content,
            author_id=user.id,
            chat_id=message.chat_id,
        )
        session.add(new_message)
        await session.commit()

        return {"message": "Message created successfully."}


@router_message.post("/chat/create")
async def create_chat(chat: ChatCreateModel, user: User = Depends(current_user)) -> dict:
    async with AsyncSession(async_engine) as session:
        new_chat = Chat(
            chat_name=chat.chat_name,
            members=chat.members
        )
        session.add(new_chat)
        await session.commit()

        return {"message": "Chat created successfully."}
